    <!DOCTYPE html>
    <html lang="en-US">
    <head itemscope itemtype="https://schema.org/WebSite">
	    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    
	<!-- This site is optimized with the Yoast SEO plugin v16.0.2 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Home - ZohairRaj</title>
	<meta name="description" content="I am a web developer I&#039;ve had the pleasure of working with some great companies, working side by side to develop the new website."/>
	<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1"/>
	<link rel="canonical" href="https://zohairraj.com/"/>
	<meta property="og:locale" content="en_US"/>
	<meta property="og:type" content="website"/>
	<meta property="og:title" content="Home - ZohairRaj"/>
	<meta property="og:description" content="I am a web developer I&#039;ve had the pleasure of working with some great companies, working side by side to develop the new website."/>
	<meta property="og:url" content="https://zohairraj.com/"/>
	<meta property="og:site_name" content="ZohairRaj"/>
	<meta property="article:modified_time" content="2020-09-15T07:29:51+00:00"/>
	<meta name="twitter:card" content="summary_large_image"/>
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":["Person","Organization"],"@id":"https://zohairraj.com/#/schema/person/7e87df7c240abaf14811c580de55f05d","name":"Zohair Mansoor","image":{"@type":"ImageObject","@id":"https://zohairraj.com/#personlogo","inLanguage":"en-US","url":"","caption":"Zohair Mansoor"},"logo":{"@id":"https://zohairraj.com/#personlogo"},"description":"I am a web developer in Karachi, Pakistan, I've had the pleasure of working with some great companies, work side by side to creating new websites and improve the existing websites. My expertise in WordPress, Joomla, HTML, CSS, JavaScript, JQuery, or Bootstrap in making responsive mobile sites that work well cross-browser to compatibility with all devices for any types of templates. I'm also designing the logo, app icon, and cover art. My hobbies reading, explore new things, playing video games, watching movies, and playing the mouth harp. When I am not doing anything else, I watch movies or playing video games.","sameAs":["http://13.212.153.15","https://www.linkedin.com/in/zohair-mansoor-b53644119/"]},{"@type":"WebSite","@id":"https://zohairraj.com/#website","url":"https://zohairraj.com/","name":"ZohairRaj","description":"Work together","publisher":{"@id":"https://zohairraj.com/#/schema/person/7e87df7c240abaf14811c580de55f05d"},"potentialAction":[{"@type":"SearchAction","target":"https://zohairraj.com/?s={search_term_string}","query-input":"required name=search_term_string"}],"inLanguage":"en-US"},{"@type":"WebPage","@id":"https://zohairraj.com/#webpage","url":"https://zohairraj.com/","name":"Home - ZohairRaj","isPartOf":{"@id":"https://zohairraj.com/#website"},"about":{"@id":"https://zohairraj.com/#/schema/person/7e87df7c240abaf14811c580de55f05d"},"datePublished":"2019-10-20T06:09:54+00:00","dateModified":"2020-09-15T07:29:51+00:00","description":"I am a web developer I've had the pleasure of working with some great companies, working side by side to develop the new website.","breadcrumb":{"@id":"https://zohairraj.com/#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https://zohairraj.com/"]}]},{"@type":"BreadcrumbList","@id":"https://zohairraj.com/#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"item":{"@type":"WebPage","@id":"https://zohairraj.com/","url":"https://zohairraj.com/","name":"Home"}}]}]}</script>
	<meta name="google-site-verification" content="ORMQqN8w8Pb5HXHqsAt0vC-mYN8iG61f4usoKWNpOOs"/>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//www.googletagmanager.com'/>
<link rel='dns-prefetch' href='//www.google.com'/>
<link rel='dns-prefetch' href='//fonts.googleapis.com'/>
<link rel='dns-prefetch' href='//s.w.org'/>
<link rel="alternate" type="application/rss+xml" title="ZohairRaj &raquo; Feed" href="https://zohairraj.com/feed/"/>
<link rel="alternate" type="application/rss+xml" title="ZohairRaj &raquo; Comments Feed" href="https://zohairraj.com/comments/feed/"/>
		<script type="text/javascript">window._wpemojiSettings={"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/zohairraj.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.6.2"}};!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);</script>
		<style type="text/css">img.wp-smiley,img.emoji{display:inline!important;border:none!important;box-shadow:none!important;height:1em!important;width:1em!important;margin:0 .07em!important;vertical-align:-.1em!important;background:none!important;padding:0!important}</style>
	<link rel='stylesheet' id='wp-block-library-css' href='https://zohairraj.com/wp-includes/css/dist/block-library/style.min.css?ver=5.6.2' type='text/css' media='all'/>
<link rel='stylesheet' id='contact-form-7-css' href='https://zohairraj.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.4' type='text/css' media='all'/>
<link rel='stylesheet' id='bwg_fonts-css' href='https://zohairraj.com/wp-content/plugins/photo-gallery/css/bwg-fonts/fonts.css?ver=0.0.1' type='text/css' media='all'/>
<link rel='stylesheet' id='sumoselect-css' href='https://zohairraj.com/wp-content/plugins/photo-gallery/css/sumoselect.min.css?ver=3.0.3' type='text/css' media='all'/>
<link rel='stylesheet' id='mCustomScrollbar-css' href='https://zohairraj.com/wp-content/plugins/photo-gallery/css/jquery.mCustomScrollbar.min.css?ver=1.5.70' type='text/css' media='all'/>
<link rel='stylesheet' id='bwg_googlefonts-css' href='https://fonts.googleapis.com/css?family=Ubuntu&#038;subset=greek,latin,greek-ext,vietnamese,cyrillic-ext,latin-ext,cyrillic' type='text/css' media='all'/>
<link rel='stylesheet' id='bwg_frontend-css' href='https://zohairraj.com/wp-content/plugins/photo-gallery/css/styles.min.css?ver=1.5.70' type='text/css' media='all'/>
<link rel='stylesheet' id='raratheme-companion-css' href='https://zohairraj.com/wp-content/plugins/raratheme-companion/public/css/raratheme-companion-public.min.css?ver=1.3.6' type='text/css' media='all'/>
<link rel='stylesheet' id='perfect-portfolio-style-css' href='https://zohairraj.com/wp-content/themes/perfect-portfolio/style.css?ver=5.6.2' type='text/css' media='all'/>
<link rel='stylesheet' id='elegant-portfolio-css' href='https://zohairraj.com/wp-content/themes/elegant-portfolio/style.css?ver=1.0.4' type='text/css' media='all'/>
<link rel='stylesheet' id='owl-theme-default-css' href='https://zohairraj.com/wp-content/themes/perfect-portfolio/css/owl.theme.default.min.css?ver=2.2.1' type='text/css' media='all'/>
<link rel='stylesheet' id='owl-carousel-css' href='https://zohairraj.com/wp-content/themes/perfect-portfolio/css/owl.carousel.min.css?ver=2.2.1' type='text/css' media='all'/>
<link rel='stylesheet' id='perfect-portfolio-google-fonts-css' href='https://fonts.googleapis.com/css?family=Vollkorn%3Aregular%2Citalic%2C700%2C700italic%7CPoppins%3A300%2Cregular%2C500%2C600%2C700' type='text/css' media='all'/>
<link rel='stylesheet' id='perfect-scrollbar-css' href='https://zohairraj.com/wp-content/themes/perfect-portfolio/css/perfect-scrollbar.min.css?ver=1.3.0' type='text/css' media='all'/>
		<script>//<![CDATA[
var rcewpp={"ajax_url":"https://zohairraj.com/wp-admin/admin-ajax.php","nonce":"cafe1e0f76","home_url":"https://zohairraj.com"};
//]]></script>
		<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/jquery.lazy.min.js?ver=1.5.70' id='bwg_lazyload-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/jquery.sumoselect.min.js?ver=3.0.3' id='sumoselect-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/jquery.mobile.min.js?ver=1.4.5' id='jquery-mobile-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/jquery.mCustomScrollbar.concat.min.js?ver=1.5.70' id='mCustomScrollbar-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/jquery.fullscreen-0.4.1.min.js?ver=0.4.1' id='jquery-fullscreen-js'></script>
<script type='text/javascript' id='bwg_frontend-js-extra'>//<![CDATA[
var bwg_objectsL10n={"bwg_field_required":"field is required.","bwg_mail_validation":"This is not a valid email address.","bwg_search_result":"There are no images matching your search.","bwg_select_tag":"Select Tag","bwg_order_by":"Order By","bwg_search":"Search","bwg_show_ecommerce":"Show Ecommerce","bwg_hide_ecommerce":"Hide Ecommerce","bwg_show_comments":"Show Comments","bwg_hide_comments":"Hide Comments","bwg_restore":"Restore","bwg_maximize":"Maximize","bwg_fullscreen":"Fullscreen","bwg_exit_fullscreen":"Exit Fullscreen","bwg_search_tag":"SEARCH...","bwg_tag_no_match":"No tags found","bwg_all_tags_selected":"All tags selected","bwg_tags_selected":"tags selected","play":"Play","pause":"Pause","is_pro":"","bwg_play":"Play","bwg_pause":"Pause","bwg_hide_info":"Hide info","bwg_show_info":"Show info","bwg_hide_rating":"Hide rating","bwg_show_rating":"Show rating","ok":"Ok","cancel":"Cancel","select_all":"Select all","lazy_load":"1","lazy_loader":"https:\/\/zohairraj.com\/wp-content\/plugins\/photo-gallery\/images\/ajax_loader.png","front_ajax":"0"};
//]]></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/photo-gallery/js/scripts.min.js?ver=1.5.70' id='bwg_frontend-js'></script>
<script type='text/javascript' src='https://www.googletagmanager.com/gtag/js?id=UA-142515028-1' id='google_gtagjs-js' async></script>
<script type='text/javascript' id='google_gtagjs-js-after'>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());gtag("set","developer_id.dZTNiMT",true);gtag("config","UA-142515028-1",{"anonymize_ip":true});</script>
<link rel="https://api.w.org/" href="https://zohairraj.com/wp-json/"/><link rel="alternate" type="application/json" href="https://zohairraj.com/wp-json/wp/v2/pages/10"/><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://zohairraj.com/xmlrpc.php?rsd"/>
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://zohairraj.com/wp-includes/wlwmanifest.xml"/> 
<meta name="generator" content="WordPress 5.6.2"/>
<link rel='shortlink' href='https://zohairraj.com/'/>
<link rel="alternate" type="application/json+oembed" href="https://zohairraj.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fzohairraj.com%2F"/>
<link rel="alternate" type="text/xml+oembed" href="https://zohairraj.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fzohairraj.com%2F&#038;format=xml"/>
<meta name="generator" content="Site Kit by Google 1.28.0"/><!-- Google Tag Manager added by Site Kit -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-594K5BD');</script>
<!-- End Google Tag Manager -->
		<link rel="icon" href="https://zohairraj.com/wp-content/uploads/2020/01/cropped-zr-icon-32x32.png" sizes="32x32"/>
<link rel="icon" href="https://zohairraj.com/wp-content/uploads/2020/01/cropped-zr-icon-192x192.png" sizes="192x192"/>
<link rel="apple-touch-icon" href="https://zohairraj.com/wp-content/uploads/2020/01/cropped-zr-icon-180x180.png"/>
<meta name="msapplication-TileImage" content="https://zohairraj.com/wp-content/uploads/2020/01/cropped-zr-icon-270x270.png"/>
<style type='text/css' media='all'>body,button,input,select,optgroup,textarea{font-family:Poppins}.site-branding .site-title,.site-branding .site-description{font-family:Poppins}</style><style type='text/css' media='all'>body,button,input,select,optgroup,textarea{font-family:Vollkorn}section[class*="-section"] .widget-title,section[class*="-section"] .widget-title span,.section-title span,.related .related-title,.additional-posts .title,.top-footer .widget .widget-title{font-family:Vollkorn}.site-branding .site-title,.site-branding .site-description{font-family:Poppins}</style>		<style type="text/css" id="wp-custom-css">:root{--color-primary:#b13128}::selection{color:#fff;background-color:#b13128}.menu-wrap .menu-search{display:none}.header-r button.toggle-btn{background:none}.btn-readmore::before{content:'';position:absolute;top:0;left:0;width:100%;height:100%;background:var(--color-primary);border-radius:40px;z-index:-1;transform:translatex(-100%);transition:all .2s linear}.btn-readmore:hover::before{transition:all .2s linear;transform:translatex(0)}button,input[type="button"],input[type="reset"],input[type="submit"],.btn-readmore,.button-wrap .btn-cta{position:relative;z-index:1;overflow:hidden}.btn-readmore:hover{background:none}.gallery-section.style1 .text-holder,.gallery-section.style5 .text-holder,.gal-masonry .gallery-wrap .text-holder,.page-template-portfolio .gallery-wrap .text-holder{background:rgba(000,000,000,.87);transform:translateY(100%);opacity:unset;visibility:unset}.gallery-section.style1 .gallery-img:hover .text-holder,.gallery-section.style5 .gallery-img:hover .text-holder,.gal-masonry .gallery-img:hover .text-holder,.page-template-portfolio .gallery-img:hover .text-holder,.gallery-section.style1 .gallery-img:focus-within .text-holder,.gallery-section.style5 .gallery-img:focus-within .text-holder,.gal-masonry .gallery-img:focus-within .text-holder,.page-template-portfolio .gallery-img:focus-within .text-holder{opacity:unset;filter:unset;visibility:unset;transform:translateY(0)}.logo-text .site-logo .custom-logo{max-width:90px}.gallery-wrap .attachment-perfect-portfolio-fullwidth{display:none}.wpcf7-textarea{height:220px}.widget_raratheme_companion_cta_widget .bttk-cta-bg{background-attachment:fixed!important}.reorder{display:flex;flex-flow:column-reverse wrap}.site-footer{background-color:#000}.gallery-section.style1 .text-holder,.gallery-section.style5 .text-holder,.gal-masonry .gallery-wrap .text-holder,.page-template-portfolio .gallery-wrap .text-holder{top:0;left:0;right:0;bottom:0;background:rgba(000,000,000,.87)}.text-holder .gal-title a{color:#fff}.text-holder span.sub-title{color:#fff}.home .cta-section{margin-bottom:100px}.attachment-portfolio-thumbnails{width:100%}#main{position:relative}.page-id-13 .attachment-portfolio-thumbnails::before{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:rgba(255,0,0,.5);z-index:999}.services{text-align:center;display:flex;flex:1;flex-flow:row wrap}#text-2{width:100%;margin-bottom:30px}.services .widget_rrtc_icon_text_widget{width:33.33%;float:left;margin-bottom:0;flex:auto;flex-flow:column wrap;padding-top:30px;padding-bottom:30px}.services .widget_rrtc_icon_text_widget{padding-right:30px;padding-left:30px}.icon-holder{margin:0 auto 30px}.widget_rrtc_testimonial_widget{margin-top:100px}.widget_raratheme_companion_cta_widget .raratheme-cta-container .widget-title{font-size:30px;color:#fff}.single-post.full-width figure.post-thumbnail, .centered figure.post-thumbnail, .page.full-width:not(.home) figure.post-thumbnail{max-width:1170px}body.page:not(.home) header.entry-header .entry-title{margin-bottom:40px;font-size:5em;color:#fff}#post-23 .entry-content{margin-top:10px}.services .widget_rrtc_icon_text_widget .text-holder .content{font-size:1em}.services .widget_text .widget-title{font-size:2.5em;font-weight:bold}.call-to-action .widget_raratheme_companion_cta_widget .bttk-cta-bg{padding:100px 20px}.call-to-action{margin-top:120px;margin-bottom:100px}.widget_rrtc_icon_text_widget .text-holder .content{color:#000}#contact_section{padding:80px 0}.contact-section .contact-holder .widget_text:not(:first-child), .contact-section .contact-holder .widget_rtc_contact_social_links{width:100%!important}.contact-section .contact-holder .widget_rtc_contact_social_links .contact-list{display:flex;justify-content:center}.contact-info ul.contact-list li{display:flex;padding-right:40px;align-items:center}.contact-info ul.contact-list li b{padding-right:12px}.contact-info ul.contact-list li:last-child{padding-right:0}#text-3{width:100%}#main{position:relative}.page-id-13 .entry-header{position:absolute;top:9%;right:50%;transform:translateX(50%)}.bottom-footer .foot-social{visibility:hidden}@media screen and (max-width:640px){.services .widget_text .widget-title{font-size:1.75em}.services .widget_rrtc_icon_text_widget .text-holder .content{font-size:.938em}body.page:not(.home) header.entry-header .entry-title{font-size:1.75em}}@media screen and (max-width:540px){.services .widget_rrtc_icon_text_widget{width:100%}.services .widget_rrtc_icon_text_widget{padding-left:15px;padding-right:15px}body.page:not(.home) header.entry-header .entry-title{font-size:1.875em}}@media screen and (max-width:414px){.testimonial-content p{font-size:.875em}.widget_rrtc_testimonial_widget .testimonial-meta .name{font-size:1.12em}}@media screen and (max-width:320px){section[class*="-section"] .widget-title,.section-title,.page-header .page-title{font-size:1.563em}.services .widget_text .widget-title{font-size:1.563em}body.page:not(.home) header.entry-header .entry-title {font-size:1.563em}}</style>
		</head>

<body class="home page-template-default page page-id-10 wp-custom-logo full-width centered-content" itemscope itemtype="https://schema.org/WebPage">

		<!-- Google Tag Manager (noscript) added by Site Kit -->
		<noscript>
			<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-594K5BD" height="0" width="0" style="display:none;visibility:hidden"></iframe>
		</noscript>
		<!-- End Google Tag Manager (noscript) -->
		    <div id="page" class="site">
        <a class="skip-link screen-reader-text" href="#main-content-area">Skip to content (Press Enter)</a>
        
        <header class="site-header" itemscope itemtype="https://schema.org/WPHeader">
        <div class="tc-wrapper">
                            
                <div class="site-branding logo-text" itemscope itemtype="https://schema.org/Organization">
                                            <div class="site-logo">
                            <a href="https://zohairraj.com/" class="custom-logo-link" rel="home" aria-current="page"><img width="137" height="138" src="https://zohairraj.com/wp-content/uploads/2020/01/zohairraj-logo.png" class="custom-logo" alt="zohair raj logo" srcset="https://zohairraj.com/wp-content/uploads/2020/01/zohairraj-logo.png 137w, https://zohairraj.com/wp-content/uploads/2020/01/zohairraj-logo-60x60.png 60w" sizes="(max-width: 137px) 100vw, 137px"/></a>                        </div>
                                                                <div class="site-title-wrap">
                                                                                                <h1 class="site-title" itemprop="name"><a href="https://zohairraj.com/" rel="home" itemprop="url">ZohairRaj</a></h1>
                                                                <p class="site-description" itemprop="description">Work together</p>
                                                    </div>
                                    </div><!-- .site-branding -->
                		<div class="header-r">
                                                <button type="button" class="toggle-btn mobile-menu-opener" data-toggle-target=".main-menu-modal" data-toggle-body-class="showing-main-menu-modal" aria-expanded="false" data-set-focus=".close-main-nav-toggle"><i class="fa fa-bars"></i></button>	

                <div class="menu-wrap">      
                    <nav id="site-navigation" class="main-navigation">        
                        <div class="primary-menu-list main-menu-modal cover-modal" data-modal-target-string=".main-menu-modal">
                            <button class="close close-main-nav-toggle" data-toggle-target=".main-menu-modal" data-toggle-body-class="showing-main-menu-modal" aria-expanded="false" data-set-focus=".main-menu-modal"></button>
                            <div class="mobile-menu" aria-label="Mobile">
                                <div class="menu-menu-container"><ul id="primary-menu" class="nav-menu main-menu-modal"><li id="menu-item-17" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-17"><a title="Home" href="https://zohairraj.com/" aria-current="page">Home</a></li>
<li id="menu-item-16" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-16"><a title="About us" href="https://zohairraj.com/about-us/">About Us</a></li>
<li id="menu-item-234" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-234"><a href="https://zohairraj.com/portfolio/">Portfolio</a></li>
<li id="menu-item-358" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-358"><a href="https://zohairraj.com/contact-us/">Contact Us</a></li>
</ul></div>                                <ul class="menu-search">
                                    <form role="search" method="get" id="search-form" class="searchform" action="https://zohairraj.com/">
                <div>
                    <label class="screen-reader-text" for="s">Search for:</label>
                    <input type="text" class="search-field" placeholder="Search..." value="" name="s"/>
                    <input type="submit" id="searchsubmit" class="search-submit" value="Search"/>
                </div>
            </form>                                </ul>
                                                                <ul class="menu-social">
                                        <ul class="social-icons">
    	            <li><a href="https://www.linkedin.com/in/zohair-mansoor-b53644119/" target="_blank" rel="nofollow"><i class="fab fa-linkedin-in"></i></a></li>    	   
            	</ul>
                                        </ul>
                            </div>
                        </div>
                    </nav><!-- #mobile-site-navigation -->
                    <!-- <button type="button" class="toggle-button">
                        <span class="toggle-bar"></span>
                        <span class="toggle-bar"></span>
                        <span class="toggle-bar"></span>
                    </button>  -->        
                </div>
    		</div>
        </div>		
	</header>
    <div id="main-content-area">	<section id="about_section" class="about-section">
		    			<div class="image-holder">
    			 	<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1077.552" height="697.612" viewBox="0 0 1077.552 697.612">
    			        <defs>
    			            <pattern id="pattern" width="1" height="1" viewBox="81.399 99.602 778.004 503.684">
    			                <image preserveAspectRatio="xMidYMid slice" width="900" height="900" xlink:href="https://zohairraj.com/wp-content/uploads/2019/11/SquareLite_20191121152946458-e1574338621889.jpg"/>
    			            </pattern>
    			        </defs>
    	        		<path id="kal-loftus-1169698-unsplash" d="M546.63,1h3.255c6.835,9.882,13.833,18.7,23.761,14.689,4.231,12.019,14.81,6.944,19.2,20.3,3.743,10.95,14.81,13.354,20.018,5.075,19.367-31.515,47.685-21.9,64.61,1.87,6.184,8.814,11.067,1.335,16.437.534,2.441-.534,4.72-5.075,7.324-.8.488,2.137.976,3.739,2.767,2.137,3.906-3.2,7-7.745,10.579-11.751,4.069-4.807,8.3-10.149,14-6.41a6.085,6.085,0,0,1,.976,3.2c-.325,3.472-2.441,4.006-3.418,6.41.976-1.87,2.441-2.4,3.58-4.273,1.628-2.938,3.255-5.876,4.72-9.081a20.843,20.843,0,0,1,1.627-2.4,16.209,16.209,0,0,1,2.767-2.671,6.065,6.065,0,0,1,2.116-1.068c.651-.267,1.465-.534,2.116-.8C751.691,11.95,759.178,3.671,768.129,1h1.628c4.394,3.2,9.439,1.6,14,4.54,2.279,1.335,5.208,2.671,5.371,6.677.163,5.609-3.418,5.609-5.859,7.211-1.79,1.068-3.58,1.6-5.371,2.671-4.557,2.671-9.276,5.075-13.345,9.081a1.537,1.537,0,0,1-1.3.8c.814.8,1.3-.534,1.953-.8,1.953-1.87,3.743-3.739,6.022-1.6,2.278,6.944-1.627,9.081-3.743,12.553-2.278,3.472-1.3,4.807,1.139,5.342,1.465,1.335,2.116,3.2,1.79,6.143-1.139,4.006-3.092,6.677-4.882,9.615-2.6,3.2-4.232,7.745-6.51,11.217-.325,1.335-1.953.534-1.79,2.938a1.7,1.7,0,0,1,1.465-.534c2.116,1.068,3.418,3.739,4.882,6.41,1.79,5.075,4.72,6.41,7.975,6.677,3.092,1.87,4.069,5.342,2.441,10.149a22.481,22.481,0,0,0-1.139,9.882c.814,2.938,1.3,1.335,1.79-.267a17.9,17.9,0,0,1,1.953-4.807,12.968,12.968,0,0,1,1.3-1.87c.814-1.6.488-3.739.814-5.609,4.231-9.882,12.206-7.478,17.414-14.155,3.906-1.068,6.184-6.41,9.114-9.882,8.463-6.944,15.3-17.627,23.11-26.174,1.79-1.87,3.581-4.006,5.371-5.609,1.953-1.6,4.069-3.2,5.533.8,1.3,3.472-.326,5.609-1.627,8.012a32.208,32.208,0,0,1-3.092,4.273A28.02,28.02,0,0,0,829.484,65.1c-1.139,3.472-3.255,5.876-4.72,9.081-.163.534-.488.8-.651,1.335a14.842,14.842,0,0,1-1.628,2.137q-2.685,2.4-1.465,7.211c1.79,3.472,3.906,1.335,6.022,1.068s4.394-1.87,5.7,2.4c1.139,4.006-.976,6.41-2.116,9.081-2.279,5.342-5.7,9.348-8.137,14.422a11.063,11.063,0,0,1-1.139,2.671c-.488,1.335-1.139,2.671-1.628,3.739a13.15,13.15,0,0,0-1.139,3.739c-.163.8-.163,1.87-.326,2.671.326,1.068.488,1.068.651,0a2.821,2.821,0,0,0,.651-.8c.488-.534,1.139-1.068,1.628-1.6,5.208-3.472,6.835-15.491,13.671-15.224a12.077,12.077,0,0,1,.977,3.2c.163,7.211-3.092,10.683-5.7,15.224-3.743,6.677-7.812,13.354-10.579,21.366-.976,3.2-2.929,6.143-.488,9.615,2.6,0,3.58-4.273,5.7-5.876,2.278-1.6,4.231-6.143,7.324-2.938a20.111,20.111,0,0,1,.976,9.348c-1.3,8.012-5.859,11.217-8.788,17.093-.488.534-.814.8-1.3,1.335-.814,1.335-.163-.8-.488.8a8.022,8.022,0,0,0,.651-.8c2.6-1.6,3.418-6.677,6.022-8.279,1.953.534,3.743,2.137,5.7,3.2,2.279,2.4,2.116,5.609,1.465,9.348a23.126,23.126,0,0,1-.814,3.2,7.344,7.344,0,0,1-2.6,3.472c-.976,1.6-3.255.534-2.929,4.273a3.173,3.173,0,0,1,1.628-.267,5.179,5.179,0,0,1,1.953,1.6,14.2,14.2,0,0,1,.651,6.944c-.814,4.006-2.929,6.41-4.394,9.615-.163.534-.325.8-.488,1.335a5.06,5.06,0,0,1-.651,1.335,25.046,25.046,0,0,0-1.3,2.671,11.066,11.066,0,0,1-1.139,2.671,17.442,17.442,0,0,0-1.3,2.4,2.971,2.971,0,0,1-.814,1.335c.325,0,.651-.267.814-1.335a16.069,16.069,0,0,1,1.139-2.4,38.993,38.993,0,0,0,1.79-3.739l1.953-4.006c1.3-2.137,3.255-1.87,4.394-4.006.651-1.335,1.3-2.671,1.953-3.739,3.092-2.4,3.906-7.745,5.208-12.286,1.79-2.938,1.79-6.944,1.953-10.683a19.519,19.519,0,0,1,2.116-6.143,8.789,8.789,0,0,1,1.79-2.137c3.906-2.4,5.208-8.814,7.649-13.354,7.161-13.354,16.437-22.435,23.761-35.522a5.141,5.141,0,0,1,4.557-2.671c1.3.534,2.116,1.6,2.6,3.472a13.053,13.053,0,0,1-.163,5.609c-2.279,4.273-4.72,8.279-7.812,14.956,3.743-6.944,6.672-11.217,10.09-14.689,7.161-5.609,13.508-13.621,19.041-22.435,10.9-17.627,24.412-29.379,36.293-44.6a58.329,58.329,0,0,1,20.994-17.093c2.116-1.068,4.557-1.335,5.533,2.938.976,3.739-.977,5.609-2.6,7.211C953.335,64.832,942.431,82.192,931.2,98.751c-3.418,4.807-6.51,9.882-10.09,14.422a66.849,66.849,0,0,0,8.951-12.286c3.743-3.739,6.347-10.416,11.23-11.484a8.264,8.264,0,0,1,5.371,2.938,7.954,7.954,0,0,1,.651,3.472,5.022,5.022,0,0,1-1.628,2.4c-2.767,2.137-5.859,3.472-7,9.081-.325,1.068-.814,2.137-1.139,2.938a7.445,7.445,0,0,1-1.79,1.87c-3.58,2.137-5.7,6.677-7.324,12.019-5.534,14.422-11.392,28.578-19.53,39.528-2.93,2.671-4.069,7.478-5.045,12.286a5.347,5.347,0,0,1-1.628,2.137c-5.045,1.87-6.835,11.217-11.555,13.888a9.755,9.755,0,0,0-3.581,10.416c2.6,12.286-2.116,16.559-7.649,20.565-1.953,1.335-4.068.267-6.022,1.068-1.465,1.068-2.441,2.938-3.092,5.342-.814,3.2-.162,6.143,0,9.348-.488,5.609,1.628,5.876,4.069,5.609,2.278,1.6,3.906,3.739,3.092,8.279-.651,1.335.163-.267-.488,1.068-.488,1.068-1.139,1.6-1.465,2.938.488-1.068.976-1.87,1.465-2.938,1.3-3.739,3.092-4.807,5.534-2.4,3.58,5.342,6.835,3.739,9.765-1.6,1.628-2.4,3.255-5.075,5.859-5.342,2.116.267,3.418,2.4,4.069,5.342.488,3.2-.488,6.41-.488,9.615a17.15,17.15,0,0,0,.651,4.006c.488,1.068.814,2.4,1.3,3.472.326,1.068.651,2.4.976,3.472.326.534.651,1.068,1.3,1.068a3.27,3.27,0,0,1,1.465-.534,5.054,5.054,0,0,1,3.418.267,9.979,9.979,0,0,1,2.116,2.137c.651.534,1.465,1.068,2.279.534a8.3,8.3,0,0,0,1.79-2.671l1.465-4.006c1.3-4.807,3.417-8.814,6.347-11.217a11.518,11.518,0,0,0,3.092-4.006,56.544,56.544,0,0,1,2.6-6.677c1.465-2.137,3.092-4.006,4.069-6.944,1.465-3.2,2.6-6.677,4.232-9.882,3.092-3.472,4.557-9.882,8.463-11.217a3.408,3.408,0,0,1,3.255,1.335c.488,9.615-4.557,14.155-7.161,21.1-1.79,4.273-4.231,8.012-5.859,12.553-2.116,4.807-4.394,9.348-5.7,14.689-.814,1.87-2.6,1.6-3.418,3.472a28.3,28.3,0,0,0-1.465,4.273,24.094,24.094,0,0,0-.976,3.2c-.326,1.6.488,2.671.163,1.068s1.465-.267.325-.8c.651-1.87,1.139-3.739,1.628-5.609.814-4.006,4.394-2.671,5.045-7.211,1.465-5.876,4.72-9.882,6.835-15.224,3.743-5.876,6.184-13.888,11.718-15.758,1.79,1.068,3.092,3.472,4.557,5.342a11.07,11.07,0,0,1,1.627,6.677c-4.069,10.683-8.463,21.1-12.532,32.05-1.627,4.807-4.069,8.279-6.347,12.286-.488,2.4-3.58,4.273-.651,7.478,1.628,1.335,2.6,3.472,3.255,6.143a17.7,17.7,0,0,1,.163,5.075c2.767,5.609,4.557-2.137,6.835-1.6a5.01,5.01,0,0,1,3.417,0,5.9,5.9,0,0,1,1.953,1.87,11.276,11.276,0,0,1,.814,3.472c-1.628,14.689-6.51,26.441-11.881,37.925-2.767,2.4-5.533,4.807-6.347,11.217,2.6-1.87,3.255-6.143,5.208-8.547,5.371-5.609,7.324-16.826,13.183-21.366a3.893,3.893,0,0,1,2.929.534c.651.267,1.139.267,1.79.534a4.182,4.182,0,0,0,1.79-.267,17.446,17.446,0,0,0,2.441-2.137c1.465-1.6,3.092-2.137,4.72-1.068,1.953,1.6,3.906,2.671,5.7-.534,2.116-3.2,4.882-5.342,4.557-11.217A7.3,7.3,0,0,1,981,312.949a9.979,9.979,0,0,0,1.953-2.938c.326-1.068.488-1.87.814-2.938.976-2.4,1.953-4.807,1.465-7.745.814-6.143,4.232-6.143,6.835-8.012a8.392,8.392,0,0,0,2.6-2.4,6.922,6.922,0,0,1,1.628-1.87,2.545,2.545,0,0,1,1.953-.267,5.4,5.4,0,0,1,1.79,1.335c1.139,1.87,2.6,3.739,3.743,5.609,2.441,6.143-1.139,10.95-1.627,16.292-.814,5.876-3.743,10.149-5.208,15.224a12.186,12.186,0,0,1-1.79,2.671c.488,0,.814-.534,1.139-1.335,2.279-8.012,6.673-11.751,10.741-16.292,4.394-4.807,6.672-12.286,9.927-18.7,4.231-8.279,8.626-16.559,15.135-20.565,2.116,0,3.092-2.4,4.069-4.807.326-8.814,4.557-10.95,8.463-13.087,1.465-.534,3.092-1.6,4.394.8a15.307,15.307,0,0,1,.326,9.348c-2.767,4.807-5.534,9.615-6.51,16.292-.326,1.87-2.278,2.137-1.953,4.807.326,1.6-.488-.267.651-.534a6.128,6.128,0,0,1,4.231-2.137c1.628,2.137,2.279-.534,3.255-1.87a3.8,3.8,0,0,0,.814-.8,2.48,2.48,0,0,1,1.953,0,8.862,8.862,0,0,1,2.767,2.4,8.186,8.186,0,0,1,.976,2.938c.326,6.143-2.441,9.615-4.394,13.621-2.116,5.075-.163,6.41,2.441,7.211a4.828,4.828,0,0,1,1.465,2.4,12.445,12.445,0,0,1,.163,3.472,19.436,19.436,0,0,1-1.465,4.54,28.209,28.209,0,0,0-1.628,4.273c-.814,3.472.163,6.677,1.139,9.615a14,14,0,0,0,2.116,4.807c.488.267.488,1.87.976,1.87.326,0,.488-1.335.488-2.137a7.573,7.573,0,0,1,2.6-4.54,6.049,6.049,0,0,1,1.953-.8c2.279,0,3.906,1.87,5.045,5.075a16.708,16.708,0,0,1,.814,2.671,5.189,5.189,0,0,0,2.116,2.938c2.929,1.068,5.37-2.671,8.137-1.87,1.139.534,1.79,1.87,2.115,3.739-.651,10.683-4.72,18.428-8.3,26.441a7.219,7.219,0,0,1-.488,1.335,5.047,5.047,0,0,1-.651,1.335c-.488.8-.814,1.6-1.3,2.4a17.667,17.667,0,0,0-1.628,4.006,23.121,23.121,0,0,1-.814,3.205c.489,4.006-5.533,6.944-.814,11.751,1.627,3.2-.814,6.143-.326,9.348,3.255,4.807,4.231-.534,5.7-3.472,9.439-18.161,18.879-36.323,32.061-47.807a4.433,4.433,0,0,1,3.255,1.6c.814,10.149-4.557,14.155-7.812,20.031-2.279,4.273-4.394,7.478.325,10.683a9.235,9.235,0,0,1,3.58,6.944c-1.465,12.553-9.277,17.627-12.694,28.043-2.6,3.739-3.255,7.211.651,9.882-2.929,13.354-5.7,26.708-12.369,36.59a5.95,5.95,0,0,0-3.092,5.609c-1.627,7.745-5.371,13.087-7.486,20.031a24.735,24.735,0,0,1-2.767,5.609A45.871,45.871,0,0,0,1057,508.985a23.985,23.985,0,0,1-1.465,2.671c-6.51,11.484-16.437,14.956-23.11,26.441-1.953,3.2-5.859,5.342-6.672-2.671-.977-8.279-3.58-4.807-5.859-2.671-2.6,2.4-4.557,6.41-7.161,8.814-2.279,2.137-4.883,6.677-7.161,2.4-1.953-3.472.651-7.211,1.79-10.149-2.116,3.739-4.882,7.478-7.812,2.938-2.767-4.273.651-8.012,2.279-10.95,3.418-6.41,7.486-11.752,9.765-19.5,1.627-3.2,3.906-6.143.814-10.416-.651-1.6.163-5.609-1.627-5.074-8.951,2.938-6.836-4.006-4.069-11.751a39.48,39.48,0,0,0,1.953-5.876c-3.417,2.938-4.557,10.416-8.788,11.751a3.6,3.6,0,0,1-2.279-.534,4.506,4.506,0,0,1-1.139-2.938c0-1.87.976-2.938,1.3-4.54a19.434,19.434,0,0,0,.163-2.938c.325-1.068.163-1.335-.488-1.335a3.063,3.063,0,0,1,.325,2.137,8.089,8.089,0,0,1-.651,2.938c-1.139,1.335-1.79,3.472-2.6,5.342a8.8,8.8,0,0,1-1.79,2.137c-5.859,5.342-11.067,12.019-16.926,17.36a49.011,49.011,0,0,0-2.6,5.609,79.533,79.533,0,0,1-3.906,8.547c-4.394,5.609-7.324,13.087-9.439,21.366-.651,2.671-2.441,4.807.326,8.547,2.767,3.472-.651,6.944-2.441,8.814a26,26,0,0,0-6.835,17.093,22.9,22.9,0,0,1-2.767,9.348c-5.7,11.751-11.23,23.77-16.112,36.857-6.184,16.292-14.973,18.963-23.924,8.547-3.743-4.273-2.116-11.217-2.6-17.627-2.441,2.938-4.069,6.677-6.184,9.348-3.581,4.807-7,6.143-8.463-3.205-.977-6.143-3.092-5.342-6.022-4.54-5.045,1.335-9.928-.534-14.159-6.143-1.465-5.342-.976-10.95-1.465-16.559.163-3.2.163-6.143-1.465-8.279-.326-.267-.488,1.869-1.139,2.4-1.627,1.6-3.255,2.938-5.045,1.335-1.953-2.938-3.418-6.677-5.859-8.547-4.069-3.2-4.882-8.547-3.418-15.224.163-1.335,1.139-1.87.814-3.472a13.949,13.949,0,0,1-.814,2.4c-5.045,16.559-5.045,16.559-15.949,10.149-.977-.8-1.953-2.938-3.255-1.068-.976,1.335-1.953,2.4-2.929,3.739a57.83,57.83,0,0,0-4.394,5.609c-1.139,1.87-2.278,3.2-3.418,4.807-1.3,3.472,1.628,2.4,1.79,4.273.976,2.671.488,4.54-.651,6.944-6.835,14.155-14,27.776-19.53,43.8-4.394,12.553-12.043,21.633-17.739,32.584-1.465,2.671-4.069,5.342-5.7,2.938-5.045-6.677-11.392-9.348-16.437-15.491-2.441-2.938-3.581-7.211-7.161-4.273a2.287,2.287,0,0,1-3.092,0c-8.788-8.012-18.878-12.286-24.9-26.975-2.278-5.342-7.486-5.342-8.626-13.888-.326-2.137-5.371,2.137-7.649,6.41-7.161,13.888-11.88,30.714-19.367,44.335-1.465,2.671-2.6,5.609-3.906,8.547-7.161,14.956-8.463,14.689-17.739,2.4-4.394-5.876-9.114-14.422-16.437-9.348-1.953,1.335-4.72.8-6.022-2.137-5.208-12.553-13.02-8.279-20.181-9.081-.651.267-1.465.534-2.116.8a14.026,14.026,0,0,0-4.557,5.342c-8.951,18.161-21.645,27.509-33.526,38.727h-3.255c-6.835-9.882-13.834-18.963-23.924-14.689-4.557-9.348-13.508-7.478-17.414-16.826-3.743-8.814-9.114-9.882-14.159-13.621-2.116-1.6-3.58,0-5.208,1.87a32.2,32.2,0,0,0-3.092,4.273c-13.833,23.5-30.6,20.565-47.685,14.155-5.7-2.137-9.928-9.348-14.159-14.956-7-9.348-13.345-6.677-20.018-.8-1.627,1.335-3.255,3.2-5.371,2.671-1.465-4.273-2.929-6.944-6.347-2.671-4.557,5.609-8.625,12.286-14.159,15.758-2.929,1.87-5.859,5.342-9.114,1.6-.977-2.4-.977-4.54.163-6.41.488-.534.976-1.6,1.627-1.87-.651-.267-.814.8-1.465,1.068-2.116,3.2-3.906,6.677-5.859,9.882a19.479,19.479,0,0,1-2.441,3.472,6.733,6.733,0,0,1-2.116,1.336c-.651.267-1.465.534-2.278.8-8.788,3.472-16.112,13.354-25.063,15.224h-1.627c-4.72-3.472-9.928-1.6-14.647-5.074-1.953-1.335-4.557-2.4-4.72-6.143-.325-5.074,2.767-5.609,4.882-6.944,1.953-1.335,4.069-1.87,6.022-3.2,3.906-2.4,7.975-4.273,12.857-8.547-3.418,2.137-5.533,3.472-7.649,1.335-1.627-8.28,3.418-9.348,5.533-13.354,2.767-5.075-.163-4.006-1.628-4.808-1.465-1.335-2.116-3.2-1.79-5.876,1.628-4.807,4.069-8.279,6.022-12.553,1.139-2.137,2.279-4.54,3.418-6.677a8.3,8.3,0,0,1,1.628-2.137c.325-.534,1.3,0,1.3-1.6,0-1.87.163.8-.651-.267a3.22,3.22,0,0,1-1.465-1.335c-.651-2.4-.976-4.807-2.6-6.143a8.788,8.788,0,0,0-8.788-3.472c-3.743-1.87-4.394-5.876-2.767-11.217.977-3.2,1.953-6.143,1.627-9.882-1.139-4.807-1.953-.8-2.767.534-3.255,16.292-12.694,18.7-20.669,24.3-3.581,1.869-5.859,6.677-8.788,10.149-1.627,1.6-3.255,2.938-4.882,4.54-7,7.211-13.183,16.826-20.343,23.77-2.929,2.938-6.51,10.683-9.6,3.472-2.441-5.876,2.767-9.081,5.045-13.087a26.566,26.566,0,0,0,5.208-10.95,22.253,22.253,0,0,1,5.045-9.081c1.953-2.4,4.394-4.54,2.441-9.615-2.278-2.938-4.72-.8-7-.267-1.627.267-3.418.8-4.394-2.137-.814-2.671.325-5.074,1.139-7.211,2.767-7.211,7.649-11.484,9.6-19.5.488-2.137,1.627-3.2,2.6-4.54a11.8,11.8,0,0,0,1.465-3.472c0-.8.163-1.87.163-2.671a4.3,4.3,0,0,0-.488-2.137l-.651-.267s-.651.267-.651.534a18.826,18.826,0,0,0-1.628,3.472c-4.069,5.075-6.022,16.025-13.02,14.155a12.069,12.069,0,0,1-.977-3.2c3.255-13.621,11.392-20.832,15.461-33.385.976-3.2,3.255-6.143.976-9.882-2.6,0-3.906,3.739-5.859,5.609-2.6,2.137-4.72,6.677-8.137,3.739-1.139-3.739-.163-7.478.325-11.217,1.628-7.211,5.371-11.751,8.463-16.826a2.5,2.5,0,0,0,1.79-1.6c.326-.8,0-1.068-.325.267a2.82,2.82,0,0,1-.651.8c-2.441,1.068-3.418,6.143-6.347,5.876-1.627-.267-2.929-1.87-3.906-4.006a16.43,16.43,0,0,1-.651-7.478,26.786,26.786,0,0,1,.814-3.472c2.441-3.2,5.208-5.609,4.72-11.751,2.278-5.876,4.069-12.019,3.255-19.23.163-.8.651-1.6.488-2.4l-.326,1.068s-.326,1.068-.488,1.068l-.977,2.4-.651,1.068a13.875,13.875,0,0,1-2.278,2.671c-1.465,1.068-2.929,1.6-4.069,3.472a51.77,51.77,0,0,1-3.418,5.609c-2.6,2.4-1.953,7.211-2.929,10.683a15.043,15.043,0,0,0-3.255,10.149c-2.116,1.6.325,4.54-.488,6.41a7.145,7.145,0,0,1-3.58,3.472,2.007,2.007,0,0,1-1.79-1.068c-.488-.8-.651-2.671-1.465-1.87-.976.8-.814,2.671-.976,4.273-1.465,13.354-8.788,20.031-13.833,28.043-4.882,8.012-10.741,15.758-17.251,21.1-1.953,0-2.767-2.137-3.092-5.074a13.55,13.55,0,0,1,.326-3.739c1.627-5.075,4.72-8.279,6.673-12.019-2.116,2.938-4.069,7.478-7.324,9.615-8.788,8.013-16.437,18.7-23.924,29.379-14,20.3-29.457,36.857-45.732,52.081-3.255,3.2-6.835,5.609-10.579,6.143-1.953.267-3.906,0-4.72-3.472-.814-4.006.814-5.876,2.6-6.944,14.973-9.615,25.877-28.31,37.432-45.4,3.418-4.808,6.673-9.882,10.09-14.422-3.255,4.006-6.51,7.745-9.277,12.82-3.58,3.472-6.022,10.416-10.9,9.348a4.939,4.939,0,0,1-2.6-3.472c.325-5.342,3.092-8.279,4.557-12.553a13.664,13.664,0,0,1,3.58-4.273c3.58-2.137,6.022-6.41,7.324-12.286A306.206,306.206,0,0,1,225.043,538.1c2.116-3.2,5.371-5.075,4.72-11.217a6.408,6.408,0,0,1,1.953-4.006c4.231,1.6,4.882-5.876,7.812-7.745,1.627-.534,2.929-2.4,3.743-4.808a8.3,8.3,0,0,1,1.627-2.137,9.957,9.957,0,0,0,2.116-8.012c-2.6-13.621,2.767-18.161,8.788-22.168,1.953-1.335,4.069,0,5.859-1.335a13.46,13.46,0,0,0,2.6-4.54c1.627-3.2.163-5.876-.488-8.814-.488-3.2-1.139-5.876-3.255-6.944q-2.929-2.8-2.929-8.012c0-.8.163-1.335.651-1.6-.977,0-.814,1.6-1.139,2.4-1.953,3.472-3.743,2.137-5.7,0-2.441-4.807-4.72-6.944-7.161.267-1.627,3.739-3.743,6.143-6.673,5.609a5.513,5.513,0,0,1-3.743-3.2,13.653,13.653,0,0,1-.651-6.41v-4.273a16.864,16.864,0,0,0-.488-4.006,28.789,28.789,0,0,1-1.139-3.472c-.163-.8-.488-1.6-.651-2.4a2.021,2.021,0,0,0-1.3-1.335c-.488.267-.976.267-1.627.534a5.053,5.053,0,0,1-3.418-.267,9.984,9.984,0,0,1-2.116-2.137,2.387,2.387,0,0,0-2.278-.534,12.667,12.667,0,0,0-1.953,2.671,41.359,41.359,0,0,0-1.627,4.006c-.977,6.143-4.394,8.547-6.835,12.286-1.465,3.739-4.231,5.876-5.7,9.348-1.139,2.137-2.441,4.006-3.58,6.143a44.818,44.818,0,0,0-5.208,10.683c-2.116,4.273-4.231,8.547-7.486,10.683a3.2,3.2,0,0,1-3.255-1.068c-.651-13.087,6.835-18.428,10.09-27.776,2.116-4.006,3.743-8.547,5.859-12.553a23.228,23.228,0,0,1,3.092-6.677c.976-1.87,2.6-2.671,3.418-4.807l.325-.534c-.488-.8-.651-.534-.814.534-1.139,1.87-2.929,2.137-3.906,4.54-.977,2.137-1.79,4.807-2.6,7.211-1.627,2.938-3.092,6.143-4.72,9.348-4.394,5.342-6.51,15.758-13.345,15.224-1.465-1.335-2.278-3.472-3.092-5.609a17.128,17.128,0,0,1-1.3-7.211c3.906-11.751,8.463-22.969,12.532-34.453,2.278-3.472,4.882-6.677,6.51-11.217,1.3-3.2,2.6-6.143,4.72-8.279.976-.267-.651-1.6-.163,0,0,.267-.814.8-1.3,1.068a3.4,3.4,0,0,1-2.278-.267c-1.79-1.068-2.929-3.472-3.58-6.143l-.488-3.2c-2.767-5.609-4.394,2.4-6.835,1.6a5.009,5.009,0,0,1-3.418,0,5.906,5.906,0,0,1-1.953-1.869,11.274,11.274,0,0,1-.814-3.472c.976-15.758,7.324-26.975,12.043-39.528,2.441-1.87,5.208-2.671,6.673-9.615-2.278,3.472-3.743,6.677-5.7,8.012-5.208,6.143-7.161,17.36-13.183,21.9-.976.267-1.953-.267-2.929-.534a4.59,4.59,0,0,0-1.79-.534,4.182,4.182,0,0,0-1.79.267c-.814.534-1.627,1.335-2.441,1.87-1.3,1.068-2.441,1.6-3.906.8-2.278-2.137-4.394-4.006-6.347.534-2.767,3.739-5.371,7.478-6.022,13.621a11.2,11.2,0,0,1-1.3,2.671,20.389,20.389,0,0,0-2.278,3.472c-1.953,3.472-2.6,8.012-3.906,12.019-3.255,4.006-5.859,9.081-9.765,11.217a3.166,3.166,0,0,1-2.116-.8,59.614,59.614,0,0,1-4.069-5.876c-3.58-5.075.651-11.217-.651-16.559,3.418-4.006,4.557-11.484,7.975-15.224.814-1.068,1.139-2.938,1.953-4.273-.814,1.068-.814,2.938-1.627,4.006-3.906,4.807-6.347,12.019-10.9,15.223-4.231,4.54-6.51,11.752-9.6,17.894-4.394,8.547-8.788,16.826-15.3,21.1-2.116,0-3.092,2.4-4.069,4.807-.326,8.814-4.394,10.683-8.3,13.087-1.465.8-2.929,1.6-4.394-.534-1.3-4.006-.488-7.478.814-10.95,2.6-4.273,4.231-9.615,5.371-15.224a26.44,26.44,0,0,1,1.627-2.938c.163-.267,1.465-.8.163-1.6-.976-.8.325,0-.814.534a16.6,16.6,0,0,1-3.58,1.6,10.454,10.454,0,0,0-3.255,2.4c-.326.267-.488.534-.814.8a3.9,3.9,0,0,1-1.79.534,9.048,9.048,0,0,0-2.6-.534,4.869,4.869,0,0,1-2.767-.534,5.814,5.814,0,0,1-.814-2.938c.488-6.41,3.418-10.149,5.859-14.422,1.3-3.2,1.627-5.876-1.3-6.944a8.484,8.484,0,0,1-1.953-1.335,8.34,8.34,0,0,1-1.139-2.938,25.044,25.044,0,0,1-.326-3.472,12.773,12.773,0,0,1,.488-3.472,13.421,13.421,0,0,1,1.3-2.938c2.116-2.4,2.441-5.342.651-8.547-.814-1.87-1.465-3.739-2.6-4.807-.814-.267-1.465,0-2.116,1.068a7.291,7.291,0,0,1-1.139,2.137,11.4,11.4,0,0,1-1.465,1.87c-.326.267-.651.267-.976.534a4.943,4.943,0,0,1-1.953.267c-2.116-.534-3.58-2.938-5.045-5.342a6.737,6.737,0,0,1-.814-2.671,9.93,9.93,0,0,1,.325-2.4,4.3,4.3,0,0,0,.488-2.137,1.7,1.7,0,0,0-1.465-.534c-2.441.267-4.557,3.2-7.161,2.137-1.139-.534-1.79-1.87-2.278-3.739-.651-6.944.488-12.82,4.069-17.093a41.35,41.35,0,0,0,1.627-4.006,40.313,40.313,0,0,1,2.441-7.211,20.136,20.136,0,0,1,1.3-2.671c.163-.534.488-.8.651-1.335.325-1.068.814-1.87,1.139-2.938,1.465-5.342,6.347-8.814,3.743-16.559-.814-2.671-.163-5.342-.163-8.279-2.278-4.006-2.278-4.006-6.184,3.2-7.812,14.957-16.437,28.845-25.063,42.2-1.953,2.938-4.069,5.609-7,5.876a4.434,4.434,0,0,1-3.255-1.6c-.814-9.882,4.394-13.621,7.486-19.5,1.79-3.472,4.231-6.143.163-9.615A18.393,18.393,0,0,1,33,311.346c1.465-12.553,9.277-17.36,12.532-27.509,2.441-3.472,3.092-6.41-.976-7.745,2.116-14.689,6.184-27.509,12.532-38.459a6.345,6.345,0,0,0,3.255-5.609c1.465-7.745,5.371-13.087,7.486-20.031a53.6,53.6,0,0,1,2.6-5.876A98.153,98.153,0,0,0,77.594,192.5c6.835-13.888,17.577-17.894,24.9-29.913,2.441-4.006,6.51-6.41,7.161,4.273.325,6.41,3.092,2.938,4.72,1.87,2.929-2.137,5.045-6.944,7.975-9.348,1.953-1.6,4.231-3.739,5.859,0,1.465,3.2-.814,5.342-1.465,7.745.977-1.068,1.953-3.2,3.418-4.006,2.116-1.335,4.557-2.137,6.022,1.068,1.79,3.739-.325,6.677-1.627,9.081-4.231,7.478-8.788,14.422-11.88,23.5-1.627,3.739-.488,7.211.325,10.683,0,.8.325,2.137.814,2.137,8.626.267,8.788.534,4.557,12.82-.488,1.335-1.3,2.671-1.3,4.54,3.58-3.2,4.557-12.019,9.765-11.484a4.827,4.827,0,0,1,1.628,1.335,5.88,5.88,0,0,1,0,3.739l.488.8.488-1.068a15.094,15.094,0,0,1,2.767-4.807c6.184-6.143,11.881-13.087,17.739-20.031l1.953-1.6c2.116-2.4,1.79-7.478,3.906-10.149,4.394-5.609,7.324-13.087,9.439-21.366.814-2.938,2.767-5.342-.488-8.547-2.278-2.4-.163-5.876,1.3-7.478,4.394-4.807,6.51-11.484,7.812-19.5a30.083,30.083,0,0,1,3.255-9.081c5.533-11.484,11.067-22.969,15.624-35.522,6.184-16.826,13.833-19.23,23.761-9.615,2.6,2.4,2.767,3.472,3.418,17.627,1.953-3.2,3.743-6.41,5.859-9.348,3.743-5.075,7-5.876,8.463,3.2.977,6.143,2.929,5.342,6.022,4.54,5.045-1.335,9.928.534,14.159,5.876,1.628,5.075.651,10.95,1.79,16.292.976,2.137,0,6.41,2.6,6.677,1.627-1.335,3.255-4.273,5.208-1.6,1.627,2.938,3.092,6.143,5.371,7.745,4.069,3.472,5.045,8.814,3.092,15.491a13.6,13.6,0,0,1-1.465,2.938c.976.267.976-1.335,1.465-1.87C287.863,123.59,287.863,123.59,298.6,130c.977.8,1.953,2.938,3.255,1.068.977-1.335,1.953-2.4,2.929-3.739a57.841,57.841,0,0,0,4.394-5.609c1.139-1.87,2.278-3.2,3.418-4.807,1.465-3.472-1.627-2.4-1.79-4.273-1.465-3.472,0-5.342,1.139-8.012C318.3,90.739,325.295,77.919,330.5,62.7c4.72-13.354,12.532-22.969,18.879-34.72,1.79-3.2,4.557-4.006,6.673-1.335,3.906,5.342,9.765,7.478,12.694,12.286,4.231,6.677,8.626,4.807,12.531,7.478,8.788,6.41,18.716,11.751,24.575,25.64,2.116,5.075,7.812,5.342,7.486,14.689,0,1.068,6.022-.8,8.626-5.876,7.649-15.491,13.182-33.652,21.32-48.608,1.627-2.938,2.929-6.41,4.557-9.348,5.533-10.149,7.975-9.882,14-.8,5.208,7.745,10.416,16.559,18.879,11.751,1.465-.8,3.906-.534,4.557,1.6,3.255,12.019,10.741,7.211,15.949,10.95,3.743,2.671,7.649-1.068,10.253-5.876C521.242,22.9,534.1,12.484,546.63,1Z" transform="translate(-28.848 -1)" fill="url(#pattern)"/>
    	    		</svg>
    			</div>
                		<div class="tc-wrapper">
			<section id="rrtc_icon_text_widget-2" class="widget widget_rrtc_icon_text_widget">        
            <div class="rtc-itw-holder">
                <div class="rtc-itw-inner-holder">
                    <div class="text-holder">
                    <h2 class="widget-title" itemprop="name">HI, I’m Zohair Mansoor</h2><div class="content"><p>I am a web developer in Karachi, Pakistan, I've had the pleasure of working with some great companies, working side by side to develop new websites and improve upon existing websites. I'm working with WordPress, Joomla, HTML, CSS, Javascript, JQuery and Bootstrap mobile responsive sites.</p>
</div><a class="btn-readmore" href="http://13.212.153.15/about-us">Read More</a>                              
                    </div>
                                            <div class="icon-holder">
                            <img width="853" height="853" src="https://zohairraj.com/wp-content/uploads/2019/11/SquareLite_20191121152946458-e1574338621889.jpg" class="attachment-full size-full" alt="HI, I’m Zohair Mansoor" loading="lazy"/>                        </div>
                                    </div>
            </div>
        </section><section id="rtc_social_links-3" class="widget widget_rtc_social_links">            <ul class="social-networks">
                                                <li class="rtc-social-icon-wrap">
                                    <a title="linkedin-in " target=_blank href="https://www.linkedin.com/in/zohair-mansoor-b53644119/">
                                        <span class="rtc-social-links-field-handle"> <i class="fab fa-linkedin-in "></i></span>
                                    </a>
                                </li>
                                        </ul>
        </section>		</div>
	</section> <!-- .about-section -->
    <section id="gallery_section" class="gallery-section style1">
	<div class="tc-wrapper">
		        <div class="button-group filter-button-group">        
            <button data-filter="*" class="is-checked">All</button>
            <button data-filter=".4">HTML</button><button data-filter=".5">Joomla</button><button data-filter=".3">WordPress</button>        </div>            
                                
        <div class="gallery-wrap">
                               
                <div class="gallery-img 5">
                                            <a href="https://zohairraj.com/portfolio/textile-techno/"><img width="800" height="776" src="https://zohairraj.com/wp-content/uploads/2020/07/textiletechno-800x776.jpg" class="attachment-perfect-portfolio-square size-perfect-portfolio-square wp-post-image" alt="textiletechno" loading="lazy" itemprop="image"/></a>
                                        <div class="text-holder">
                        <div class="text-holder-inner">
                            <h2 class="gal-title"><a href="https://zohairraj.com/portfolio/textile-techno/">Textile Techno-Commercial Consultants</a></h2>
                                                            <span class="sub-title">
                                    <a href="https://zohairraj.com/portfolio-category/joomla/"><span>Joomla</span></a>                                </span>
                                                    </div>
                    </div>
                </div>
                               
                <div class="gallery-img 3">
                                            <a href="https://zohairraj.com/portfolio/real-assignment-services/"><img width="800" height="800" src="https://zohairraj.com/wp-content/uploads/2020/01/ras-home-half-800x800.jpg" class="attachment-perfect-portfolio-square size-perfect-portfolio-square wp-post-image" alt="real assignment services featured image" loading="lazy" itemprop="image" srcset="https://zohairraj.com/wp-content/uploads/2020/01/ras-home-half-800x800.jpg 800w, https://zohairraj.com/wp-content/uploads/2020/01/ras-home-half-150x150.jpg 150w" sizes="(max-width: 800px) 100vw, 800px"/></a>
                                        <div class="text-holder">
                        <div class="text-holder-inner">
                            <h2 class="gal-title"><a href="https://zohairraj.com/portfolio/real-assignment-services/">Real Assignment Services</a></h2>
                                                            <span class="sub-title">
                                    <a href="https://zohairraj.com/portfolio-category/wordpress/"><span>WordPress</span></a>                                </span>
                                                    </div>
                    </div>
                </div>
                               
                <div class="gallery-img 3">
                                            <a href="https://zohairraj.com/portfolio/karachi-stationers/"><img width="800" height="800" src="https://zohairraj.com/wp-content/uploads/2020/01/karachistationers-800x800.jpg" class="attachment-perfect-portfolio-square size-perfect-portfolio-square wp-post-image" alt="karachi stationers featured image" loading="lazy" itemprop="image" srcset="https://zohairraj.com/wp-content/uploads/2020/01/karachistationers-800x800.jpg 800w, https://zohairraj.com/wp-content/uploads/2020/01/karachistationers-150x150.jpg 150w" sizes="(max-width: 800px) 100vw, 800px"/></a>
                                        <div class="text-holder">
                        <div class="text-holder-inner">
                            <h2 class="gal-title"><a href="https://zohairraj.com/portfolio/karachi-stationers/">Karachi Stationers</a></h2>
                                                            <span class="sub-title">
                                    <a href="https://zohairraj.com/portfolio-category/wordpress/"><span>WordPress</span></a>                                </span>
                                                    </div>
                    </div>
                </div>
                               
                <div class="gallery-img 4">
                                            <a href="https://zohairraj.com/portfolio/httpeak/"><img width="800" height="800" src="https://zohairraj.com/wp-content/uploads/2020/01/httpeak-800x800.jpg" class="attachment-perfect-portfolio-square size-perfect-portfolio-square wp-post-image" alt="httpeak" loading="lazy" itemprop="image" srcset="https://zohairraj.com/wp-content/uploads/2020/01/httpeak-800x800.jpg 800w, https://zohairraj.com/wp-content/uploads/2020/01/httpeak-150x150.jpg 150w" sizes="(max-width: 800px) 100vw, 800px"/></a>
                                        <div class="text-holder">
                        <div class="text-holder-inner">
                            <h2 class="gal-title"><a href="https://zohairraj.com/portfolio/httpeak/">Httpeak</a></h2>
                                                            <span class="sub-title">
                                    <a href="https://zohairraj.com/portfolio-category/html/"><span>HTML</span></a>                                </span>
                                                    </div>
                    </div>
                </div>
                               
                <div class="gallery-img 4">
                                            <a href="https://zohairraj.com/portfolio/manshur-solutions/"><img width="800" height="800" src="https://zohairraj.com/wp-content/uploads/2019/12/manshur-solutions-featured-800x800.jpg" class="attachment-perfect-portfolio-square size-perfect-portfolio-square wp-post-image" alt="manshur solutions featured" loading="lazy" itemprop="image" srcset="https://zohairraj.com/wp-content/uploads/2019/12/manshur-solutions-featured-800x800.jpg 800w, https://zohairraj.com/wp-content/uploads/2019/12/manshur-solutions-featured-150x150.jpg 150w" sizes="(max-width: 800px) 100vw, 800px"/></a>
                                        <div class="text-holder">
                        <div class="text-holder-inner">
                            <h2 class="gal-title"><a href="https://zohairraj.com/portfolio/manshur-solutions/">Manshur Solutions</a></h2>
                                                            <span class="sub-title">
                                    <a href="https://zohairraj.com/portfolio-category/html/"><span>HTML</span></a>                                </span>
                                                    </div>
                    </div>
                </div>
                    </div><!-- .row .grid -->
        <a href="http://13.212.153.15/portfolio/" class="btn-readmore">View More</a>	</div>
</section> <!-- .gallery-section -->
	<section id="service_section" class="service-section">
		<div class="tc-wrapper">
			<div class="widgets-holder">
				<section id="text-2" class="widget widget_text"><h2 class="widget-title" itemprop="name">What I Love Doing</h2>			<div class="textwidget"><p>I take every task seriously. Things I do flawlessly.</p>
</div>
		</section><section id="rrtc_icon_text_widget-3" class="widget widget_rrtc_icon_text_widget">        
            <div class="rtc-itw-holder">
                <div class="rtc-itw-inner-holder">
                    <div class="text-holder">
                    <h2 class="widget-title" itemprop="name">Web Development</h2><div class="content"><p>Our website design is meaningful and impactful leaving a long-lasting impression on the viewer's mind. Fully Responsive, interactive and clean websites.</p>
</div>                              
                    </div>
                                            <div class="icon-holder">
                            <span class="fas fa-code"></span>
                        </div>
                                    </div>
            </div>
        </section><section id="rrtc_icon_text_widget-4" class="widget widget_rrtc_icon_text_widget">        
            <div class="rtc-itw-holder">
                <div class="rtc-itw-inner-holder">
                    <div class="text-holder">
                    <h2 class="widget-title" itemprop="name">Graphic Design</h2><div class="content"><p>I'm creating the successful building the brand so our client’s services and products stand apart from their competitors. We offer our services such as logo design, apps icon, cover arts.</p>
</div>                              
                    </div>
                                            <div class="icon-holder">
                            <span class="fas fa-bezier-curve"></span>
                        </div>
                                    </div>
            </div>
        </section><section id="rrtc_testimonial_widget-2" class="widget widget_rrtc_testimonial_widget">        
            <div class="rtc-testimonial-holder">
                <div class="rtc-testimonial-inner-holder">
                                            <div class="img-holder">
                            <img width="200" height="199" src="https://zohairraj.com/wp-content/uploads/2019/10/testimonial-image.jpg" class="attachment-rttk-thumb size-rttk-thumb" alt="Hussain Mansoor" loading="lazy" srcset="https://zohairraj.com/wp-content/uploads/2019/10/testimonial-image.jpg 200w, https://zohairraj.com/wp-content/uploads/2019/10/testimonial-image-150x150.jpg 150w, https://zohairraj.com/wp-content/uploads/2019/10/testimonial-image-60x60.jpg 60w" sizes="(max-width: 200px) 100vw, 200px"/>                        </div>
                            
                    <div class="text-holder">
                        <div class="testimonial-meta">
                           <span class="name">Hussain Mansoor</span><span class="designation">Cloud Architect @Manshur Solutions</span>                        </div>                              
                        <div class="testimonial-content"><p>"Zohair has designed many logos, cover art and landing pages for me. For every task, I got few choices to select from, all being production ready and polished. Exporting the designs to multiple resolutions or tweaking them according to my needs has never been a problem and always on time. I will highly recommend him for any type of designing and he's my go to designer for all my projects."</p>
</div>                    </div>
                </div>
            </div>
        </section>			</div>
		</div>
	</section> <!-- .service-section -->
	<section id="contact_section" class="contact-section">
		<div class="tc-wrapper">
            <div class="contact-holder">
			    <section id="text-5" class="widget widget_text"><h2 class="widget-title" itemprop="name">Get in Touch</h2>			<div class="textwidget"><p>Are you looking to start a project then let’s go built together unique websites with our creative tool, feel free to email &amp; we&#8217;ll quickly be in touch.</p>
</div>
		</section><section id="rtc_contact_social_links-3" class="widget widget_rtc_contact_social_links">            
        <div class="rtc-contact-widget-wrap contact-info">
        <ul class="contact-list"><li><i class="fa fa-phone"></i><b>Phone</b><a href="tel:03342657912">03342657912</a></li><li><i class="fa fa-envelope"></i><b>Email</b><a href="mailto:zohair.mansoor@gmail.com">zohair.mansoor@gmail.com</a></li></ul>                
                <ul class="social-networks">
                                                        <li class="rtc-contact-social-icon-wrap">
                                        <a target=_blank href="https://www.linkedin.com/in/zohair-mansoor-b53644119/">
                                            <span class="rtc-contact-social-links-field-handle"><i class="fab fa-linkedin"></i></span>
                                        </a>
                                    </li>
                                                </ul>
                        </div>
        </section>            </div>
		</div>
	</section> <!-- .contact-section -->
</div><!-- #main-content-area -->
    <div class="overlay"></div>
    <footer id="colophon" class="site-footer" itemscope itemtype="https://schema.org/WPFooter">
        <div class="bottom-footer">
        <div class="tc-wrapper">
            <div class="copyright">           
                &copy; Copyright 2021 <a href="https://zohairraj.com/">ZohairRaj</a>.  <a href="" rel="nofollow" target="_blank"></a>  <a href="" target="_blank"></a>               
            </div>
            <div class="foot-social">
                    <ul class="social-icons">
    	            <li><a href="https://www.linkedin.com/in/zohair-mansoor-b53644119/" target="_blank" rel="nofollow"><i class="fab fa-linkedin-in"></i></a></li>    	   
            	</ul>
                    </div>
        </div>
    </div>
        <button class="back-to-top">
        <i class="fa fa-long-arrow-up"></i>
    </button>
        </footer><!-- #colophon -->
            </div><!-- #page -->

    <script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=7.4.4' id='wp-polyfill-js'></script>
<script type='text/javascript' id='wp-polyfill-js-after'>('fetch'in window)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-fetch.min.js?ver=3.0.0"></scr'+'ipt>');(document.contains)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-node-contains.min.js?ver=3.42.0"></scr'+'ipt>');(window.DOMRect)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-dom-rect.min.js?ver=3.42.0"></scr'+'ipt>');(window.URL&&window.URL.prototype&&window.URLSearchParams)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-url.min.js?ver=3.6.4"></scr'+'ipt>');(window.FormData&&window.FormData.prototype.keys)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-formdata.min.js?ver=3.0.12"></scr'+'ipt>');(Element.prototype.matches&&Element.prototype.closest)||document.write('<script src="https://zohairraj.com/wp-includes/js/dist/vendor/wp-polyfill-element-closest.min.js?ver=2.0.2"></scr'+'ipt>');</script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/i18n.min.js?ver=ac389435e7fd4ded01cf603f3aaba6a6' id='wp-i18n-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/vendor/lodash.min.js?ver=4.17.19' id='lodash-js'></script>
<script type='text/javascript' id='lodash-js-after'>window.lodash=_.noConflict();</script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/url.min.js?ver=98645f0502e5ed8dadffd161e39072d2' id='wp-url-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/hooks.min.js?ver=84b89ab09cbfb4469f02183611cc0939' id='wp-hooks-js'></script>
<script type='text/javascript' id='wp-api-fetch-js-translations'>(function(domain,translations){var localeData=translations.locale_data[domain]||translations.locale_data.messages;localeData[""].domain=domain;wp.i18n.setLocaleData(localeData,domain);})("default",{"locale_data":{"messages":{"":{}}}});</script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/dist/api-fetch.min.js?ver=4dec825c071b87c57f687eb90f7c23c3' id='wp-api-fetch-js'></script>
<script type='text/javascript' id='wp-api-fetch-js-after'>wp.apiFetch.use(wp.apiFetch.createRootURLMiddleware("https://zohairraj.com/wp-json/"));wp.apiFetch.nonceMiddleware=wp.apiFetch.createNonceMiddleware("8984381b7f");wp.apiFetch.use(wp.apiFetch.nonceMiddleware);wp.apiFetch.use(wp.apiFetch.mediaUploadMiddleware);wp.apiFetch.nonceEndpoint="https://zohairraj.com/wp-admin/admin-ajax.php?action=rest-nonce";</script>
<script type='text/javascript' id='contact-form-7-js-extra'>//<![CDATA[
var wpcf7=[];
//]]></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.4' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/raratheme-companion/public/js/isotope.pkgd.min.js?ver=3.0.5' id='isotope-pkgd-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/masonry.min.js?ver=4.2.2' id='masonry-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/raratheme-companion/public/js/raratheme-companion-public.min.js?ver=1.3.6' id='raratheme-companion-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/raratheme-companion/public/js/fontawesome/all.min.js?ver=5.6.3' id='all-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/raratheme-companion/public/js/fontawesome/v4-shims.min.js?ver=5.6.3' id='v4-shims-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/themes/perfect-portfolio/js/owl.carousel.min.js?ver=2.2.1' id='owl-carousel-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/themes/perfect-portfolio/js/perfect-scrollbar.min.js?ver=1.3.0' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/themes/perfect-portfolio/js/modal-accessibility.min.js?ver=1.0.4' id='perfect-portfolio-modal-accessibility-js'></script>
<script type='text/javascript' id='perfect-portfolio-custom-js-extra'>//<![CDATA[
var perfect_portfolio_data={"rtl":"","ajax_url":"https:\/\/zohairraj.com\/wp-admin\/admin-ajax.php"};
//]]></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/themes/perfect-portfolio/js/custom.min.js?ver=1.0.4' id='perfect-portfolio-custom-js'></script>
<script type='text/javascript' src='https://www.google.com/recaptcha/api.js?render=6LdwccMUAAAAAPnQaP8hVcElsWwP-S6mlKUfxgUk&#038;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>//<![CDATA[
var wpcf7_recaptcha={"sitekey":"6LdwccMUAAAAAPnQaP8hVcElsWwP-S6mlKUfxgUk","actions":{"homepage":"homepage","contactform":"contactform"}};
//]]></script>
<script type='text/javascript' src='https://zohairraj.com/wp-content/plugins/contact-form-7/modules/recaptcha/index.js?ver=5.4' id='wpcf7-recaptcha-js'></script>
<script type='text/javascript' src='https://zohairraj.com/wp-includes/js/wp-embed.min.js?ver=5.6.2' id='wp-embed-js'></script>

</body>
</html>

/*This file was exported by "Export WP Page to Static HTML" plugin which created by ReCorp (https://myrecorp.com) */